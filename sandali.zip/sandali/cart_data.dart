class CartItemModel {
  late final String imagePath;
  late final String name;
  late final String price;
  CartItemModel(
      {required this.imagePath, required this.name, required this.price});
  static final cartItemList = [
    CartItemModel(
        imagePath: "assets/images/sapphire.png",
        name: "Sapphire",
        price: "22Ct, 89\$"),
    
    
    
  ];
}
